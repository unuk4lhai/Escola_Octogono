const AlunoService = require('../services/AlunoService');

module.exports = {

    alterar: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let n_de_faltas = req.body.n_de_faltas;

        if(id_aluno){
            await AlunoService.alterar(id_aluno);
            json.result = {
                nome_aluno,
                n_de_faltas
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    }

}