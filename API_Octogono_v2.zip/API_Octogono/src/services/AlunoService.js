const db= require('../db');

module.exports= {

    alterar: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET n_de_faltas = n_de_faltas+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    }

    
}