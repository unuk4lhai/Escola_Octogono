const ProfessorService = require('../services/ProfessorService');

module.exports = {
    buscarTodos: async (req, res) => {
        let json = { error: '', result: [] };

        let professores = await ProfessorService.buscarTodos();

        for (let i in professores) {
            json.result.push({
                id_professor: professores[i].id_professor,
                nome_professor: professores[i].nome_professor
            });
        }
        res.json(json);
    },
    buscarUm: async (req, res) => {
        let json = { error: '', result: null };

        const { id } = req.params; // Captura o ID da requisição

        let professor = await ProfessorService.buscarUm(id);

        if (professor) {
            json.result = {
                id_professor: professor.id_professor,
                nome_professor: professor.nome_professor
            };
        } else {
            json.error = 'Professor não encontrado';
        }

        res.json(json);
    }
}
    
