const express = require('express');
const router = express.Router();

const ProfessorController = require('./controllers/ProfessorController');

router.get('/professores', ProfessorController.buscarTodos);
router.get('/professor/:id_professor', ProfessorController.buscarUm);


module.exports = router;
