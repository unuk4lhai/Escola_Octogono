const AlunoService = require('../services/AlunoService');

module.exports = {

    alterar: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let n_de_faltas = req.body.n_de_faltas;

        if(id_aluno){
            await AlunoService.alterar(id_aluno);
            json.result = {
                nome_aluno,
                n_de_faltas
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    buscarAlunos: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarAlunos();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno
            });
        }
        res.json(json);
    },

    buscaAlunoPorNome: async (req, res) => {
        let json = { error: '', result: {} };
    
        let nome_aluno = req.params.nome_aluno; // Acessa o parâmetro nome_aluno da requisição
        let aluno = await AlunoService.buscaAlunoPorNome(nome_aluno);
    
        if (aluno) {
            json.result = aluno;
        } else {
            json.error = 'aluno não encontrado';
        }
    
        res.json(json);
    }


}