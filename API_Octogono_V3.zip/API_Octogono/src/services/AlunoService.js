const db= require('../db');

module.exports= {

    alterar: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET n_de_faltas = n_de_faltas+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    buscarAlunos: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno ', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },


    buscaAlunoPorNome: (nome_aluno) => {
        return new Promise((aceito, rejeitado)=>{

            db.query('SELECT * FROM Aluno WHERE nome_aluno = ?', [nome_aluno], (error, results)=>{
                if (error){rejeitado(error); return;}
                if (results.length>0){
                    aceito(results[0]);
                } else{
                    aceito(false);
                }
            });
        });
    }
    
}