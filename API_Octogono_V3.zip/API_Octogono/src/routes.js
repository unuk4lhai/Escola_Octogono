const express = require('express');
const router = express.Router();

const ProfessorController = require('./controllers/ProfessorController');
const AlunoController = require('./controllers/AlunoController');

router.get('/professores', ProfessorController.buscarTodos);
router.get('/professor/:id_professor', ProfessorController.buscarUm);
router.get('/alunos', AlunoController.buscarAlunos);
router.get('/aluno/:nome_aluno', AlunoController.buscaAlunoPorNome);
router.put('/aluno/:id_aluno', AlunoController.alterar);

module.exports = router;
